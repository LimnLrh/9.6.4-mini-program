//app.js
// const Towxml = require('/towxml/main');
App({
  onLaunch: function () {

  },
  // towxml: new Towxml(),
  globalData: {
    userInfo: null
  }
})