const baseUrl = "https://m.yaojunrong.com"//基础域名

const fetch = {
  http(url, method, data) {
    return new Promise((resolve,reject)=>{
      let token=wx.getStorageSync("token")
      let header = {
        "content-type": "application/json"//json格式的请求头
        }
        if(token){
          header.token=token
        }
        
      wx.request({
        url: baseUrl+url,
        data,
        method,
        header,
        success(res) {
          console.log(res)
          if(res.header.Token){
            wx.setStorageSync("token",res.header.Token)
          }
          resolve(res.data)
        },
        fail(err) {
          reject(err)
        }
      })
    })
  },
  get(url,data) {
    return this.http(url,"GET",data)
  },
  post(url,data){
    return this.http(url,"POST",data)
  }
}

const login=()=>{
  wx.login({
    success(res){
      fetch.post("/login",{
        code:res.code,
        appid:"wxd13d8528e829e58e",
        secret:"01bcbad390adb1ff82f2f61e120ad352"
      }).then(res=>{
        console.log(res)
      })
    }
  })
}
exports.login=login
exports.fetch=fetch;